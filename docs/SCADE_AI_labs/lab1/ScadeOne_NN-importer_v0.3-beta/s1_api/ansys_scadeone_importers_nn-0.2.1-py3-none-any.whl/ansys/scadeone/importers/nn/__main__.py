# -*- coding: utf-8 -*-
"""CLI module entrypoint for the neural network importer."""

from . import main


if __name__ == "__main__":
    raise SystemExit(main())
