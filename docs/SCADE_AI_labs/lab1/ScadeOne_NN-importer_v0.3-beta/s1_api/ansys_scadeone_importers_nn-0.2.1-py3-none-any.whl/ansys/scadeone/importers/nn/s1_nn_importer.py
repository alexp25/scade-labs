# -*- coding: utf-8 -*-
"""Keras to SCADE One importer public API and CLI entrypoint."""

# MIT License
#
# Copyright (c) 2024 ANSYS, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Optional, Sequence, Union

# Disable TensorFlow informational logs before importing tensorflow/keras.
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
logging.getLogger("tensorflow").setLevel(logging.ERROR)

import numpy as np  # type: ignore
from keras import Model  # type: ignore

from ._model_creator import ModelCreator
from ._version import __version__
from .utils import improve_array_pprint  # noqa: F401

# Check Python compatibility with TensorFlow.
assert (3, 10) <= sys.version_info < (3, 13), "Requires Python 3.10 to 3.12"

ModelOrPath = Union[Model, Path, str]
PathStr = Union[Path, str]

_IMPORTER_VERSION = __version__
_KERAS_LIB = Path(__file__).parent / "keras_lib"


def import_keras_in_s1(
    model: ModelOrPath,
    root: PathStr,
    clean_first: bool = True,
    keras_lib_path: Optional[Path] = None,
    tests_inputs: Optional[list[np.ndarray]] = None,
) -> None:
    """Import a Keras model into a SCADE One project.

    Parameters
    ----------
    model : Model | Path | str
        Keras model instance or path to a ``.h5``/``.keras`` model file.
    root : Path | str
        Output directory or ``.sproj`` location.
    clean_first : bool, default: True
        Whether an existing output can be cleaned/recreated.
    keras_lib_path : Path | None, default: None
        Path to an external Keras helper library (``.sproj`` or its parent folder).
        When ``None``, the bundled library is copied into the project.
    tests_inputs : list[np.ndarray] | None, default: None
        Optional input samples used to generate a test harness.
    """
    if keras_lib_path is None:
        # Bundled lib is inside the package; copy it so the project is portable.
        lib_path, copy_lib = _KERAS_LIB, True
    else:
        lib_path, copy_lib = keras_lib_path, False
    creator = ModelCreator(
        model,
        sproj_or_outdir=root,
        keras_lib_path=lib_path,
        copy_keras_lib=copy_lib,
        exists_ok=clean_first,
        importer_version=_IMPORTER_VERSION,
    )
    creator.create_module()
    if tests_inputs is not None:
        creator.create_test_harness(tests_inputs)
    creator.write()


def _build_parser() -> argparse.ArgumentParser:
    """Build the CLI parser for the importer."""
    parser = argparse.ArgumentParser(description="SCADE One Keras importer.")
    parser.add_argument("model", type=Path, help="Path to a .h5/.keras model file")
    parser.add_argument(
        "-o",
        "--outdir",
        type=Path,
        metavar="PATH",
        default=None,
        help="Output folder for the created SCADE One project",
    )
    parser.add_argument(
        "-k",
        "--keras-lib",
        type=Path,
        default=None,
        metavar="PATH",
        help="Path to an external Keras library (.sproj or folder containing keras.sproj)",
    )
    parser.add_argument(
        "-a",
        "--append",
        action="store_true",
        help="Append to an existing project instead of recreating it",
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Run the CLI importer.

    Parameters
    ----------
    argv : Sequence[str] | None, default: None
        Optional explicit argument list. When ``None``, arguments are read from
        ``sys.argv``.

    Returns
    -------
    int
        Process return code.
    """
    parser = _build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    outdir = args.outdir if args.outdir else Path(f"imported__{args.model.name}")

    keras_lib_path: Optional[Path] = None
    if args.keras_lib is not None:
        klib = args.keras_lib
        if klib.is_dir():
            sproj = klib / "keras.sproj"
        elif klib.suffix == ".sproj" and klib.name == "keras.sproj":
            sproj = klib
        else:
            print(f"Error: '{klib}' must be a keras.sproj file or a folder containing one.")
            return 1
        if not sproj.exists():
            print(f"Error: keras.sproj not found at '{sproj}'.")
            return 1
        keras_lib_path = args.keras_lib

    print("Start creation")
    import_keras_in_s1(
        args.model,
        root=outdir,
        clean_first=not args.append,
        keras_lib_path=keras_lib_path,
    )
    print(f"End creation (in {outdir.absolute()})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
