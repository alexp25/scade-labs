from ansys.scadeone.core import swan  # type: ignore


def add_test_harness(module: swan.TestModule, name: str) -> swan.TestHarness:
    """Add a test harness using the native 0.8.2 API."""
    return module.add_test_harness(name)
