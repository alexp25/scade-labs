"""API for creation of Scade One Projects"""

import json
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar, Optional, Union, cast, overload
from warnings import warn

from ansys.scadeone.core.project import Project, ResourceKind as CoreResourceKind  # type: ignore
from ansys.scadeone.core import ScadeOne, swan  # type: ignore
from ansys.scadeone.core.interfaces import IScadeOne
from ansys.scadeone.core.common.storage import ProjectStorage
from ansys.scadeone.core.common.versioning import FormatVersions

assert sys.version_info >= (3, 8), "Requires Python 3.8 or above"

PathStr = Union[Path, str]
PathOptionalContent = Union[PathStr, tuple[PathStr, str]]
PathContentDict = dict[Path, Optional[str]]

ResourcesDict = dict["ResourceKind", Union[list[PathStr], dict[str, PathStr]]]


class ResourceKind(Enum):
    """Kind of Project Resource"""

    SOURCE_FILE = "SourceFile"
    HEADER_FILE = "HeaderFile"
    SIMULATION_DATA = "SimulationData"

    def __str__(self) -> str:
        return self.value


class JsonClass:
    """Class that can be exported to JSON"""

    EXTENSION: ClassVar[str] = ".json"

    def to_dict(self) -> dict[str, Any]:
        """Transform into a dictionary for dumping to JSON"""

        def json_serializer(data: Any) -> Any:
            """JSON Serializer"""
            if isinstance(data, JsonClass):
                return data.to_dict()
            if isinstance(data, Path):
                return data.as_posix()
            if isinstance(data, ResourceKind):
                return data.value
            if isinstance(data, list):
                return [json_serializer(v) for v in data]

            return data

        return {k.title(): json_serializer(v) for k, v in self.__dict__.items()}

    @overload
    def to_json(self) -> str: ...

    @overload
    def to_json(self, path: None) -> str: ...

    @overload
    def to_json(self, path: PathStr) -> Path: ...

    def to_json(self, path: Optional[PathStr] = None) -> Union[str, Path]:
        """Dumps to JSON to a file if a path is specified, or string otherwise

        Note: if a path is provided without extension, a default extension is added
        """
        data = json.dumps(self.to_dict(), indent=2)
        if path is None:
            return data

        if not path:
            raise AttributeError("Cannot specify empty string for path")

        output = Path(path)
        if output.suffix == "":
            output = output.with_suffix(self.EXTENSION)
        output.write_text(data, encoding="utf-8")
        return output


@dataclass
class Resource(JsonClass):
    """Resource for project"""

    kind: ResourceKind
    path: PathStr
    key: str = ""

    def __post_init__(self):
        path = Path(self.path)
        resource_name = f"Resource {self.kind.value} '{self.path}'"
        if self.kind == ResourceKind.SIMULATION_DATA:
            if not self.key:
                raise AttributeError(f"{resource_name} shall have a key")
            if path.suffix != ".sd":
                raise AttributeError(f"{resource_name} shall be a .sd file")
        else:
            if self.key:
                warn(f"{resource_name} shall have no key")
            self.key = ""


class ProjectEnhanced(Project):
    """Swan Project with resources and dependencies"""

    def __init__(self, app: IScadeOne, project: ProjectStorage, is_new: bool = False) -> None:
        super().__init__(app, project, is_new=is_new)
        self._imported_code: PathContentDict = {}

    @property
    def root_dir(self) -> Path:
        """Root directory of the project"""
        project_dir = self.directory
        assert project_dir is not None, "Project directory shall be set"

        return Path(project_dir)

    @property
    def assets_dir(self) -> Path:
        """Directory for assets"""
        return self.root_dir / "assets"

    @property
    def resources_dir(self) -> Path:
        """Directory for resources"""
        return self.root_dir / "resources"

    @property
    def jobs_dir(self) -> Path:
        """Directory for jobs"""
        return self.root_dir / "jobs"

    def get_rel_dir(self, path: PathStr) -> Path:
        """Remove root folder for the resources and dependencies"""
        try:
            return Path(path).absolute().relative_to(self.root_dir.absolute())
        except ValueError:
            return Path(path)

    @classmethod
    def from_project(cls, project: Project) -> "ProjectEnhanced":
        """Create enhanced project from a project"""
        is_new = not Path(project.storage.path).exists()
        enhanced_project = cls(project.app, project.storage, is_new=is_new)
        enhanced_project._dependencies = list(project._dependencies)
        enhanced_project._jobs = dict(project._jobs)
        enhanced_project._resources = list(project.resources)
        enhanced_project._is_new = getattr(project, "_is_new", is_new)
        return enhanced_project

    def add_dependencies(self, dependencies: list[PathStr]) -> None:
        """Add dependencies for the project"""
        paths = [(Path(p) if Path(p).is_absolute() else self.directory / p) for p in dependencies]
        missing_paths = [p for p in paths if not p.exists()]
        if missing_paths:
            warn(f"Missing dependencies: {missing_paths}")
        for path in paths:
            if path.exists():
                self.add_dependency(self.app.load_project(path))

    def _get_resources_json(
        self,
        resources: list[PathStr],
        kind: ResourceKind,
    ) -> list[dict[str, str]]:
        """Generic method to get the resources as a JSON file"""
        return [Resource(kind, self.get_rel_dir(p)).to_dict() for p in resources]

    def add_imported_code(
        self,
        path: PathStr,
        content: str = "",
        append: bool = False,
    ):
        """Add (set or append) code to source file or header file"""
        path = Path(path)
        if append:
            if self._imported_code.get(path, None) is None:
                self._imported_code[path] = ""
            self._imported_code[path] += content  # type: ignore  # content is necessary a string
        else:
            self._imported_code[path] = content

    def _get_imported_kind(self, path: Path) -> ResourceKind:
        """Get the kind of resource from the path"""
        if path.suffix == ".h":
            return ResourceKind.HEADER_FILE
        return ResourceKind.SOURCE_FILE

    def save(self) -> None:
        """Persist imported files/resources, then save project via native 0.8.2 API."""
        for path, content in self._imported_code.items():
            absolute_path = path if path.is_absolute() else self.root_dir / path
            absolute_path.parent.mkdir(parents=True, exist_ok=True)
            absolute_path.write_text(content or "", encoding="utf-8")

            rel_path = self.get_rel_dir(absolute_path)
            if rel_path not in [r.path for r in self.resources]:
                resource_kind = (
                    CoreResourceKind.HEADER_FILE
                    if absolute_path.suffix == ".h"
                    else CoreResourceKind.SOURCE_FILE
                )
                self.add_resource(resource_kind, rel_path, exist_check=False)

        super().save()

    def add_module_test(self, name: str):
        """Add a test module to the model."""
        return self.add_test_module(name)
