# Single source of truth for the package version (read by flit via __init__.py import).
__version__ = "0.2.1"
