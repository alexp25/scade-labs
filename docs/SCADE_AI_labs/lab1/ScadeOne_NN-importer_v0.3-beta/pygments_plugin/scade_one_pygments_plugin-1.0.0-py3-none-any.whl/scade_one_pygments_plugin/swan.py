# Copyright © 2023-2024 ANSYS, Inc. Unauthorized use, distribution or duplication is prohibited.

from pygments.lexer import RegexLexer, bygroups, default, words
from pygments import token
from pygments.token import Keyword, Name, Text

__all__ = ['SwanLexer']

class SwanLexer(RegexLexer):
    """
    Lexer for the Swan programming language (version 2025.0, SO-SRS-001 v2.1).
    """
    name = 'swan'
    url = 'https://www.ansys.com/products/embedded-software/ansys-scade-one'
    aliases = ['swan']
    filenames = ['*.swan', '*.swani']

    tokens = {
        'root': [
            (words((
                # iterators
                'fold', 'foldi', 'forward',
                'map', 'mapfold', 'mapfoldi', 'mapi',
                'restart', 'every',
                # misc
                'end',
                # control
                'elsif', 'match', # 'else' is in operators
                'resume', 'unless', 'until', 'activate',
            ), suffix=r'\b'), token.Keyword.Builtin),
            (words((
                # declarations
                'function', 'node', 'sensor', 'type', 'const',
                'guarantee', 'returns', 'specialize', 'where',
                'expr', 'def', 'block', 'wire', 'group',
                'var', 'let', 'emit', 'assume', 'guarantee', 'diagram',
                'automaton', 'state',
                'assert',
            ), suffix=r'\b'), token.Keyword.Declaration),
            (
                r"^\s*(use)(\s*)((?:\w+::)*)(\w+)",
                bygroups(Keyword.Namespace, Text.Whitespace, Name.Namespace, Name),
            ),
            (words((
                'clock', 'initial', 'inline', 'probe',
            ), suffix=r'\b'), token.Keyword.Namespace),
            (words((
                'false', 'true',
            ), suffix=r'\b'), token.Name.Builtin),
            (words((
                # operators
                'and', 'not', 'or', 'xor',
                'land', 'lnot', 'lor', 'lsl', 'lsr', 'lxor',
                'byname', 'bypos',
                'if', 'then', 'else', 'case', 'of',
                'last', 'pre',
                'reverse', 'pack', 'transpose', 'window', 'flatten',
                'merge', 'mod', 'self', 'when', 'with', 'default',
            ), suffix=r'\b'), token.Operator.Word),
            (words((
                # types
                'bool', 'char', 'enum',
                'float32', 'float64',
                'int8', 'int16', 'int32', 'int64',
                'uint8', 'uint16', 'uint32', 'uint64',
                'numeric', 'float', 'integer', 'signed', 'unsigned',
            ), suffix=r'\b'), token.Keyword.Type),
            (words((
                'abstract', 'do', 'final','foldw', 'foldwi', 'forwardi',
                'imported', 'is', 'make', 'mapfoldw', 'mapfoldwi', 'mapw', 'mapwi',
                'onreset', 'open', 'package', 'parameter', 'private', 'public',
                'repeat', 'repeati', 'sig', 'synchro', 'tel', 'times',
                'probe', # note: probe is not "reserved but unused" in SO-SRS-001 v2.1
            ), suffix=r'\b'), token.Keyword.Reserved),
            (r'#pragma', token.Comment.Preproc, 'pragma'), # must be before LUID
            (r'/\*', token.Comment.Multiline, 'comment'),  # must be before operators
            (r'<<', token.Generic.Strong, 'chevron'),      # must be before operators
            (r'--.*$', token.Comment.Singleline),          # must be before operators
            (r'\+|-|\*|\/|\^|=|<>|<=?|>=?|->|@|:>', token.Operator),
            (r'(\d+\.\d*|\d*\.\d+)([eE][+-]?\d+)?', token.Number.Float, 'number_lit'), # TYPED_FLOAT
            (r'0b[01]+', token.Number.Bin, 'number_lit'),        # TYPED_INTEGER
            (r'0o[0-7]+', token.Number.Oct, 'number_lit'),        # TYPED_INTEGER
            (r'0x[0-9A-Fa-f]+', token.Number.Hex, 'number_lit'), # TYPED_INTEGER
            (r'\d+', token.Number.Integer, 'number_lit'),     # TYPED_INTEGER
            (r'#[\w\-]+', token.Name.Label),  # LUID
            (r'[a-zA-Z]\w*', token.Name), # ID
            (r'\s', token.Text),
            (r'\S', token.Text)
        ],
        'number_lit': [
            (r'_u?i(8|16|32|64)', token.Keyword, '#pop'),
            (r'_f(32|64)', token.Keyword, '#pop'),
            default('#pop'),
        ],
        'comment': [
            (r'[^*/]+', token.Comment.Multiline),
            (r'/\*', token.Comment.Multiline, '#push'),
            (r'\*/', token.Comment.Multiline, '#pop'),
            (r'[*/]', token.Comment.Multiline)
        ],
        'pragma': [
            (r'[^#]+', token.Comment.Preproc),
            (r'##', token.Comment.Preproc),
            (r'#end', token.Comment.Preproc, '#pop'),
        ],
        'chevron': [
            (r'>>', token.Generic.Strong, '#pop'),
            (r'.', token.Generic.Strong)
        ]
    }
